// ═══════════════════════════════════════════════════════════════════════════
// BACKGROUND SERVICE WORKER — AR Tracker CardMarket Price Sync  v5.0
// Ouvre tous les liens d'une carte en parallèle, puis passe à la suivante
// ═══════════════════════════════════════════════════════════════════════════

const DELAY_MIN_MS    = 1200;
const DELAY_MAX_MS    = 2500;
const DELAY_CN_MIN_MS = 2000;
const DELAY_CN_MAX_MS = 3500;
const TAB_LOAD_TIMEOUT = 20000;
const CAPTCHA_TIMEOUT  = 120000;
const CAPTCHA_POLL     = 1000;

function randomDelay(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

const DEFAULT_CONFIG = {
  countries:     { 'France':'FR', 'Germany':'DE', 'Luxembourg':'LU', 'Netherlands':'NL' },
  priceSelector: 'span.color-primary.small.text-end.text-nowrap.fw-bold',
  langMap: {
    'Japanese':'jp','Korean':'kr','Chinese':'cn',
    'English':'gb','French':'fr','German':'de',
    'Spanish':'es','Italian':'it','Portuguese':'pt',
    'Dutch':'nl','Polish':'pl','Russian':'ru'
  },
};

let syncState = {
  running:       false,
  queue:         [],
  results:       {},
  errors:        {},
  current:       0,
  total:         0,
  openTabs:      [],
  pendingKeys:   null,
  currentGroup:  null,
  trackerTabId:  null,
  extractConfig: null,
};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  if (msg.type === 'PING') {
    sendResponse({ ok: true, version: '5.0' });
    return true;
  }
  if (msg.type === 'GET_STATE') {
    sendResponse({ running: syncState.running, current: syncState.current, total: syncState.total });
    return true;
  }
  if (msg.type === 'START_SYNC') {
    if (syncState.running) { sendResponse({ ok: false, error: 'Sync déjà en cours' }); return true; }
    const trackerTabId = sender.tab && sender.tab.id ? sender.tab.id : null;
    console.log('[BG] START_SYNC —', msg.cards.length, 'groupes');
    startSync(msg.cards, trackerTabId, msg.extractConfig || null);
    sendResponse({ ok: true });
    return true;
  }
  if (msg.type === 'CANCEL_SYNC') {
    cancelSync();
    sendResponse({ ok: true });
    return true;
  }
  if (msg.type === 'CM_PRICE_FOUND') {
    if (msg.manualMode) {
      notifyTrackerAllTabs({ type: 'PRICE_UPDATED', key: msg.key, data: msg.data, url: msg.url });
    } else {
      handlePriceResponse(msg.key, msg.data, msg.url, true, sender.tab && sender.tab.id);
    }
    sendResponse({ ok: true });
    return true;
  }
  if (msg.type === 'CM_PRICE_NOT_FOUND') {
    if (msg.manualMode) {
      notifyTrackerAllTabs({ type: 'PRICE_NOT_FOUND', key: msg.key, data: msg.data || {}, url: msg.url });
    } else {
      handlePriceResponse(msg.key, msg.data || {}, msg.url, false, sender.tab && sender.tab.id);
    }
    sendResponse({ ok: true });
    return true;
  }
  if (msg.type === 'CM_CAPTCHA_DETECTED') {
    handleCaptcha(sender.tab ? sender.tab.id : null);
    sendResponse({ ok: true });
    return true;
  }
  return true;
});

// ── SYNC ──────────────────────────────────────────────────────────────────
function startSync(groups, trackerTabId, extractConfig) {
  syncState = {
    running: true, queue: [...groups], results: {}, errors: {},
    current: 0, total: groups.length,
    openTabs: [], pendingKeys: new Set(), currentGroup: null,
    trackerTabId, extractConfig: extractConfig || DEFAULT_CONFIG,
  };
  notifyTracker({ type: 'SYNC_STARTED', total: syncState.total });
  processNext();
}

async function processNext() {
  if (!syncState.running) return;
  if (syncState.queue.length === 0) { finishSync(); return; }

  const group = syncState.queue.shift();
  syncState.current      = syncState.total - syncState.queue.length;
  syncState.currentGroup = group;
  syncState.openTabs     = [];
  syncState.pendingKeys  = new Set(group.links.map(l => group.key + l.suffix));

  console.log('[BG]', group.key, '(', syncState.current, '/', syncState.total, ')' ,
              group.links.length, 'lien(s):', group.links.map(l => l.suffix || 'JP').join('+'));

  notifyTracker({ type: 'SYNC_PROGRESS', current: syncState.current, total: syncState.total, key: group.key });

  try {
    // Ouvre tous les onglets du groupe en parallèle
    const tabs = await Promise.all(
      group.links.map(link => chrome.tabs.create({ url: link.url, active: false }))
    );
    syncState.openTabs = tabs.map(t => t.id);

    // Attend que tous soient chargés
    await Promise.all(tabs.map(t => waitForTabLoad(t.id)));

    // Injecte données + content script dans chaque onglet
    await Promise.all(tabs.map((tab, i) => {
      const fullKey = group.key + group.links[i].suffix;
      return chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: (cardKey, config) => {
          window.__cmCardData = { key: cardKey, config };
          window.__cmPriceSyncRunning = false;
        },
        args: [fullKey, syncState.extractConfig],
      }).then(() => chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files:  ['content_cm.js'],
      }));
    }));

  } catch (e) {
    console.warn('[BG] Erreur groupe', group.key, ':', e.message);
    syncState.errors[group.key] = e.message;
    closeOpenTabs();
    syncState.pendingKeys.clear();
    scheduleNext();
  }
}

// ── RÉPONSES PRIX ─────────────────────────────────────────────────────────
function handlePriceResponse(key, data, url, found, tabId) {
  if (!syncState.running) return;

  if (tabId) {
    chrome.tabs.remove(tabId).catch(() => {});
    syncState.openTabs = syncState.openTabs.filter(id => id !== tabId);
  }

  if (found) {
    syncState.results[key] = data;
    notifyTracker({ type: 'PRICE_UPDATED', key, data, url });
  } else {
    syncState.errors[key] = 'not_found';
    notifyTracker({ type: 'PRICE_NOT_FOUND', key, data: data || {}, url });
  }

  syncState.pendingKeys.delete(key);
  console.log('[BG] Reçu', key, '— en attente:', syncState.pendingKeys.size);

  if (syncState.pendingKeys.size === 0) {
    scheduleNext();
  }
}

// ── SCHEDULING ────────────────────────────────────────────────────────────
function scheduleNext() {
  if (!syncState.running) return;
  closeOpenTabs();
  if (syncState.queue.length === 0) { finishSync(); return; }

  const nextGroup = syncState.queue[0];
  const nextHasCn = nextGroup.links.some(l => l.isCn);
  const delay = nextHasCn
    ? randomDelay(DELAY_CN_MIN_MS, DELAY_CN_MAX_MS)
    : randomDelay(DELAY_MIN_MS, DELAY_MAX_MS);

  console.log(`[BG] Prochaine carte dans ${delay}ms (${nextGroup.links.length} lien(s))`);
  setTimeout(processNext, delay);
}

function closeOpenTabs() {
  syncState.openTabs.forEach(id => chrome.tabs.remove(id).catch(() => {}));
  syncState.openTabs = [];
}

function finishSync() {
  syncState.running = false;
  closeOpenTabs();
  console.log('[BG] Sync terminé —', Object.keys(syncState.results).length, 'prix');
  notifyTracker({ type: 'SYNC_COMPLETE', count: Object.keys(syncState.results).length, errors: syncState.errors });
}

function cancelSync() {
  syncState.running = false;
  closeOpenTabs();
  if (syncState.pendingKeys) syncState.pendingKeys.clear();
  notifyTracker({ type: 'SYNC_CANCELLED' });
}

// ── CAPTCHA ────────────────────────────────────────────────────────────────
function handleCaptcha(captchaTabId) {
  if (!syncState.running) return;
  console.log('[BG] CAPTCHA sur tab', captchaTabId);

  // Ferme tous les autres onglets du groupe
  syncState.openTabs.forEach(id => { if (id !== captchaTabId) chrome.tabs.remove(id).catch(() => {}); });
  syncState.openTabs = captchaTabId ? [captchaTabId] : [];

  if (captchaTabId) chrome.tabs.update(captchaTabId, { active: true }).catch(() => {});
  notifyTracker({ type: 'CAPTCHA_NEEDED' });

  let waited = 0;
  const iv = setInterval(async () => {
    waited += CAPTCHA_POLL;
    if (waited > CAPTCHA_TIMEOUT) {
      clearInterval(iv);
      syncState.errors['captcha'] = 'CAPTCHA non résolu dans les temps';
      closeOpenTabs();
      if (syncState.pendingKeys) syncState.pendingKeys.clear();
      scheduleNext();
      return;
    }
    try {
      const tab = await chrome.tabs.get(captchaTabId);
      if (tab.status !== 'complete') return;
      const res = await chrome.scripting.executeScript({
        target: { tabId: captchaTabId },
        func: () => document.title.toLowerCase().includes('just a moment') ||
          !!document.querySelector('iframe[src*="challenges.cloudflare.com"]') ||
          !!document.querySelector('#challenge-form'),
      });
      if (res && res[0] && res[0].result) return; // toujours CAPTCHA

      // Résolu — remet le groupe en tête et réessaie
      clearInterval(iv);
      notifyTracker({ type: 'CAPTCHA_RESOLVED' });
      chrome.tabs.remove(captchaTabId).catch(() => {});
      syncState.openTabs = [];
      if (syncState.currentGroup) {
        syncState.queue.unshift(syncState.currentGroup);
        syncState.current = Math.max(0, syncState.current - 1);
      }
      setTimeout(processNext, 2000);
    } catch (e) {
      clearInterval(iv);
      closeOpenTabs();
      scheduleNext();
    }
  }, CAPTCHA_POLL);
}

// ── UTILS ─────────────────────────────────────────────────────────────────
function waitForTabLoad(tabId) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error('Tab load timeout'));
    }, TAB_LOAD_TIMEOUT);

    function listener(id, info) {
      if (id !== tabId || info.status !== 'complete') return;
      chrome.tabs.onUpdated.removeListener(listener);
      clearTimeout(timer);
      setTimeout(resolve, 300);
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

function notifyTracker(msg) {
  if (!syncState.trackerTabId) return;
  chrome.tabs.sendMessage(syncState.trackerTabId, msg)
    .then(() => console.log('[BG] → tracker:', msg.type))
    .catch(err => console.warn('[BG] → tracker FAIL:', msg.type, err.message));
}

// Mode manuel : broadcast à tous les onglets tracker ouverts
function notifyTrackerAllTabs(msg) {
  chrome.tabs.query({ url: 'https://snowmaxtop.github.io/ar-tracker/*' }, function(tabs) {
    if (!tabs || tabs.length === 0) {
      console.warn('[BG] notifyTrackerAllTabs: aucun onglet tracker trouvé');
      return;
    }
    tabs.forEach(function(tab) {
      chrome.tabs.sendMessage(tab.id, msg)
        .then(() => console.log('[BG] → tracker (manuel):', msg.type, msg.key))
        .catch(err => console.warn('[BG] → tracker (manuel) FAIL:', err.message));
    });
  });
}
