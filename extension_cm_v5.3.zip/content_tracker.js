// ═══════════════════════════════════════════════════════════════════════════
// CONTENT SCRIPT — injecté dans le tracker (GitHub Pages)
// Pont postMessage ↔ chrome.runtime
// ═══════════════════════════════════════════════════════════════════════════

console.log('[content_tracker] Injecté dans', window.location.href);

// ── Page → Extension ──────────────────────────────────────────────────────
window.addEventListener('message', function(event) {
  if (event.source !== window || !event.data) return;

  // Ping de détection
  if (event.data.__cmBridgePing) {
    window.postMessage({ __cmBridgeReady: true }, '*');
    return;
  }

  if (!event.data.__cmBridge) return;
  const msg   = event.data.msg;
  const reqId = event.data.reqId;

  chrome.runtime.sendMessage(msg, function(res) {
    const err = chrome.runtime.lastError ? chrome.runtime.lastError.message : null;
    window.postMessage({ __cmBridgeReply: true, reqId, res: res || null, err }, '*');
  });
});

// ── Extension → Page (messages spontanés du background) ──────────────────
chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
  window.postMessage({ __cmBridgeEvent: true, msg }, '*');
  sendResponse({ ok: true });
  return true;
});

console.log('[content_tracker] Bridge prêt ✅');
