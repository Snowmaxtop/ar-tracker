// popup.js — AR Tracker CM Sync
chrome.runtime.sendMessage({ type: 'PING' }, function(res) {
  const dot  = document.getElementById('dot');
  const txt  = document.getElementById('status-text');
  const ver  = document.getElementById('version');

  if (chrome.runtime.lastError || !res) {
    dot.className = 'dot err';
    txt.textContent = 'Extension inactive';
    return;
  }

  if (res.ok) {
    // Vérifie si un sync est en cours
    chrome.runtime.sendMessage({ type: 'GET_STATE' }, function(state) {
      if (state && state.running) {
        dot.className = 'dot ok';
        txt.textContent = 'Sync en cours : ' + state.current + ' / ' + state.total;
      } else {
        dot.className = 'dot ok';
        txt.textContent = 'Extension active';
      }
    });
    ver.textContent = 'v' + res.version;
  }
});
