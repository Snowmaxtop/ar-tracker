// ═══════════════════════════════════════════════════════════════════════════
// CONTENT SCRIPT — CardMarket product page  v5.3
// Mode sync   : window.__cmCardData injecté par background.js
// Mode manuel : clé lue depuis location.hash (#cmkey=SV11B-109__fr)
// ═══════════════════════════════════════════════════════════════════════════

(function () {
  if (window.__cmPriceSyncRunning) return;
  window.__cmPriceSyncRunning = true;

  // ── Détection CAPTCHA ──────────────────────────────────────────────────
  const isCaptchaPage =
    document.title.toLowerCase().includes('just a moment') ||
    !!document.querySelector('iframe[src*="challenges.cloudflare.com"]') ||
    !!document.querySelector('#challenge-form');

  if (isCaptchaPage) {
    chrome.runtime.sendMessage({ type: 'CM_CAPTCHA_DETECTED' });
    return;
  }

  // ── Résolution de la clé ───────────────────────────────────────────────
  // Mode sync  : __cmCardData injecté par background
  // Mode manuel: #cmkey=SV11B-109__fr dans l'URL
  let cardData = window.__cmCardData;
  let manualMode = false;

  if (!cardData || !cardData.key) {
    const hashMatch = location.hash.match(/[#&]cmkey=([^&]+)/);
    if (hashMatch) {
      cardData = { key: decodeURIComponent(hashMatch[1]), config: DEFAULT_CONFIG };
      manualMode = true;
      console.log('[content_cm v5.3] Mode manuel — clé:', cardData.key);
    } else {
      // Pas de clé, pas de hash → rien à faire
      return;
    }
  }

  const key    = cardData.key;
  const url    = window.location.href;
  const config = cardData.config || DEFAULT_CONFIG;

  console.log('[content_cm v5.3]', manualMode ? 'MANUEL' : 'SYNC', '—', key);

  // ── Extraction image ───────────────────────────────────────────────────
  let imageUrl = null;
  try {
    const ldEl = document.querySelector('script[type="application/ld+json"]');
    if (ldEl) {
      const ld = JSON.parse(ldEl.textContent);
      imageUrl = ld.image || (Array.isArray(ld.image) ? ld.image[0] : null);
    }
  } catch(e) {}
  if (!imageUrl) {
    const og = document.querySelector('meta[property="og:image"]');
    if (og) imageUrl = og.getAttribute('content');
  }
  if (!imageUrl) {
    const imgEl = document.querySelector('img.is-front');
    if (imgEl) imageUrl = imgEl.currentSrc || imgEl.src || null;
  }
  if (!imageUrl) {
    const fallback = document.querySelector('img[src*="product-images"], img[src*="s3.cardmarket"]');
    if (fallback) imageUrl = fallback.src;
  }

  // ── Attendre que les article-rows soient chargés (mode manuel) ─────────
  if (manualMode) {
    waitForRows(function(rows) { extractAndSend(rows); });
  } else {
    extractAndSend(document.querySelectorAll('div.article-row'));
  }

  // ── Attente des rows (polling léger) ────────────────────────────────────
  function waitForRows(cb) {
    let attempts = 0;
    const iv = setInterval(function() {
      const rows = document.querySelectorAll('div.article-row');
      if (rows.length > 0 || attempts++ > 20) {
        clearInterval(iv);
        cb(rows);
      }
    }, 300);
  }

  // ── Extraction + envoi ─────────────────────────────────────────────────
  function extractAndSend(articleRows) {
    console.log('[content_cm v5.3] Lignes:', articleRows.length);

    if (articleRows.length === 0) {
      chrome.runtime.sendMessage({
        type: 'CM_PRICE_NOT_FOUND', key, url,
        data: imageUrl ? { imageUrl } : {}
      });
      return;
    }

    const result = {};

    articleRows.forEach(row => {
      const code = getCountryCode(row, config.countries);
      if (!code) return;

      const offerCol = row.querySelector('.col-offer');
      const priceEl  = offerCol
        ? offerCol.querySelector(config.priceSelector)
        : row.querySelector(config.priceSelector);
      if (!priceEl) return;
      const price = parsePrice(priceEl.textContent);
      if (price === null) return;

      const lang = getLang(row, config.langMap);

      if (!result[lang]) result[lang] = {};
      if (result[lang][code] === undefined || price < result[lang][code]) {
        result[lang][code] = price;
      }
    });

    if (imageUrl) result.imageUrl = imageUrl;

    console.log('[content_cm v5.3] Résultat:', JSON.stringify(result));

    const anyPrice = Object.keys(result).filter(k => k !== 'imageUrl').length > 0;
    chrome.runtime.sendMessage({
      type: anyPrice ? 'CM_PRICE_FOUND' : 'CM_PRICE_NOT_FOUND',
      key, data: result, url, manualMode,
    });
  }

  // ── Helpers ─────────────────────────────────────────────────────────────
  function getCountryCode(row, countries) {
    for (const el of row.querySelectorAll('[aria-label], [title]')) {
      const lbl = el.getAttribute('aria-label') || el.getAttribute('title') || '';
      if (lbl.startsWith('Item location:')) {
        const code = countries[lbl.replace('Item location:', '').trim()];
        if (code) return code;
      }
    }
    return null;
  }

  function getLang(row, langMap) {
    const scope = row.querySelector('.col-product') || row;
    for (const el of scope.querySelectorAll('*')) {
      for (const attr of ['aria-label', 'title', 'data-original-title']) {
        const val = el.getAttribute(attr) || '';
        if (langMap[val]) return langMap[val];
      }
    }
    return 'jp';
  }

  function parsePrice(text) {
    if (!text) return null;
    const v = parseFloat(
      text.replace(/\u00a0/g, '').replace(/\s/g, '')
          .replace('€', '').replace('$', '').replace(',', '.')
    );
    return isNaN(v) ? null : v;
  }

  // ── Config par défaut (mode manuel sans injection background) ──────────
  const DEFAULT_CONFIG = {
    countries: { 'France':'FR', 'Germany':'DE', 'Luxembourg':'LU', 'Netherlands':'NL' },
    priceSelector: 'span.color-primary.small.text-end.text-nowrap.fw-bold',
    langMap: {
      'Japanese':'jp','Korean':'kr',
      'Chinese':'cn','S-Chinese':'cn','T-Chinese':'cn',
      'English':'gb','French':'fr','German':'de',
      'Spanish':'es','Italian':'it','Portuguese':'pt',
      'Dutch':'nl','Polish':'pl','Russian':'ru',
    },
  };
})();
